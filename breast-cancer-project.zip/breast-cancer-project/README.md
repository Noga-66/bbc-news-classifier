# Breast Cancer Diagnosis Prediction

A single-notebook machine learning project that predicts whether a breast tumor is
**malignant** or **benign** from the Wisconsin Diagnostic Breast Cancer dataset — plus a
live, client-side demo deployed on GitHub Pages.

## Contents

```
.
├── project.ipynb        ← the full analysis (EDA → preprocessing → modeling → SVM tuning → export)
├── data.csv              ← Wisconsin Diagnostic Breast Cancer dataset
├── model_bundle.json     ← exported logistic regression weights (also copied into docs/)
└── docs/                 ← static site deployed via GitHub Pages
    ├── index.html
    ├── styles.css
    ├── app.js
    └── model_bundle.json
```

`project.ipynb` merges and improves on the original 5-part structure (problem definition →
EDA → preprocessing → SVM model → SVM tuning), and adds:

- Automated data-quality checks (missing values, duplicates, class balance)
- A 6-model benchmark (Logistic Regression, linear & RBF SVM, Random Forest, Gradient
  Boosting, KNN) with 5-fold cross-validated ROC-AUC, instead of assuming SVM up front
- PCA visualization of class separability
- Grid-search-tuned SVM with confusion matrix + ROC curve on a held-out test set
- A final section that trains and **exports** a logistic regression model so it can run
  **entirely in the browser**, with no backend server — which is what makes a GitHub Pages
  deployment possible at all (GitHub Pages only serves static files).

## Running the notebook

```bash
pip install pandas numpy scikit-learn matplotlib seaborn
jupyter notebook project.ipynb
```

Re-running the last two cells of Part 6 regenerates `model_bundle.json` if you retrain the
model — remember to also copy the refreshed file into `docs/model_bundle.json` before
redeploying.

## Deploying to GitHub Pages

1. Create a new GitHub repository and push this project to it:

   ```bash
   git init
   git add .
   git commit -m "Breast cancer prediction: notebook + GitHub Pages demo"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<your-repo>.git
   git push -u origin main
   ```

2. On GitHub, go to **Settings → Pages**.
3. Under **Build and deployment → Source**, choose **Deploy from a branch**.
4. Under **Branch**, choose `main` and the `/docs` folder, then **Save**.
5. GitHub will publish the site at:

   ```
   https://<your-username>.github.io/<your-repo>/
   ```

   (it can take a minute or two the first time). That's it — no server, no build step, no
   secrets: `index.html` fetches `model_bundle.json` and runs the model with plain
   JavaScript.

### Updating the live demo later

Any time you retrain the model in the notebook, copy the new `model_bundle.json` into
`docs/`, commit, and push — GitHub Pages redeploys automatically from the `docs/` folder.

## Disclaimer

This is an educational project, not a medical device. Predictions from the notebook or the
deployed demo should never be used for real clinical decisions.
