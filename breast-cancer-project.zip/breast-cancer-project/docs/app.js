(function () {
  "use strict";

  const EXAMPLES = {
    benign: [13.54,14.36,87.46,566.3,0.09779,0.08129,0.06664,0.04781,0.1885,0.05766,0.2699,0.7886,2.058,23.56,0.00846,0.0146,0.02387,0.01315,0.0198,0.0023,15.11,19.26,99.7,711.2,0.144,0.1773,0.239,0.1288,0.2977,0.07259],
    malignant: [17.99,10.38,122.8,1001.0,0.1184,0.2776,0.3001,0.1471,0.2419,0.07871,1.095,0.9053,8.589,153.4,0.0064,0.04904,0.05373,0.01587,0.03003,0.00619,25.38,17.33,184.6,2019.0,0.1622,0.6656,0.7119,0.2654,0.4601,0.1189],
  };

  const GROUP_SUFFIX = { mean: "_mean", se: "_se", worst: "_worst" };

  let bundle = null;

  function niceLabel(featureName) {
    // e.g. "concave points_mean" -> "concave points"
    return featureName.replace(/_(mean|se|worst)$/, "").replace(/_/g, " ");
  }

  function buildForm() {
    const groups = { mean: [], se: [], worst: [] };
    bundle.feature_names.forEach((name, idx) => {
      for (const g of Object.keys(GROUP_SUFFIX)) {
        if (name.endsWith(GROUP_SUFFIX[g])) groups[g].push({ name, idx });
      }
    });

    for (const g of Object.keys(groups)) {
      const container = document.getElementById(`grid-${g}`);
      container.innerHTML = "";
      groups[g].forEach(({ name, idx }) => {
        const field = document.createElement("div");
        field.className = "field";
        const label = document.createElement("label");
        label.setAttribute("for", `f-${idx}`);
        label.textContent = niceLabel(name);
        label.title = name;
        const input = document.createElement("input");
        input.type = "number";
        input.step = "any";
        input.id = `f-${idx}`;
        input.dataset.idx = idx;
        input.required = true;
        input.placeholder = "0.00";
        field.appendChild(label);
        field.appendChild(input);
        container.appendChild(field);
      });
    }
  }

  function loadExample(kind) {
    const inputs = document.querySelectorAll("#feature-form input[data-idx]");
    if (kind === "clear") {
      inputs.forEach((inp) => (inp.value = ""));
      resetReadout();
      return;
    }
    const values = EXAMPLES[kind];
    inputs.forEach((inp) => {
      const idx = Number(inp.dataset.idx);
      inp.value = values[idx];
    });
  }

  function sigmoid(z) {
    return 1 / (1 + Math.exp(-z));
  }

  function predict(rawValues) {
    // rawValues: array aligned with bundle.feature_names order
    const { scaler_mean, scaler_scale, weights, bias } = bundle;
    let z = bias;
    const contributions = [];
    for (let i = 0; i < rawValues.length; i++) {
      const scaled = (rawValues[i] - scaler_mean[i]) / scaler_scale[i];
      const contribution = scaled * weights[i];
      z += contribution;
      contributions.push({ name: bundle.feature_names[i], contribution });
    }
    const probability = sigmoid(z);
    return { probability, contributions };
  }

  function updateGauge(probability) {
    const fill = document.getElementById("gauge-fill");
    const needle = document.getElementById("gauge-needle");
    const pct = Math.round(probability * 100);

    fill.setAttribute("stroke-dasharray", `${pct} 100`);
    const isMalignant = probability >= 0.5;
    fill.style.stroke = isMalignant ? "var(--rose)" : "var(--green)";

    // needle rotates from -90deg (0%) to +90deg (100%) across the semicircle
    const angle = -90 + probability * 180;
    needle.style.transform = `rotate(${angle}deg)`;

    document.getElementById("prob-value").textContent = `${pct}%`;
  }

  function updateVerdict(probability) {
    const el = document.getElementById("verdict-value");
    if (probability >= 0.5) {
      el.textContent = `Malignant (${(probability * 100).toFixed(1)}%)`;
      el.className = "verdict-value malignant";
    } else {
      el.textContent = `Benign (${((1 - probability) * 100).toFixed(1)}% confidence)`;
      el.className = "verdict-value benign";
    }
  }

  function updateDrivers(contributions) {
    const sorted = [...contributions].sort(
      (a, b) => Math.abs(b.contribution) - Math.abs(a.contribution)
    );
    const top = sorted.slice(0, 6);
    const maxAbs = Math.max(...top.map((c) => Math.abs(c.contribution)), 1e-9);

    const list = document.getElementById("drivers-list");
    list.innerHTML = "";
    top.forEach(({ name, contribution }) => {
      const li = document.createElement("li");
      const label = document.createElement("span");
      label.textContent = niceLabel(name);
      label.style.flex = "0 0 auto";
      label.style.minWidth = "110px";

      const track = document.createElement("span");
      track.className = "driver-bar-track";
      const barFill = document.createElement("span");
      barFill.className = `driver-bar-fill ${contribution >= 0 ? "up" : "down"}`;
      barFill.style.width = `${(Math.abs(contribution) / maxAbs) * 100}%`;
      track.appendChild(barFill);

      const value = document.createElement("span");
      value.textContent = contribution >= 0 ? "→ malignant" : "→ benign";
      value.style.flex = "0 0 auto";

      li.appendChild(label);
      li.appendChild(track);
      li.appendChild(value);
      list.appendChild(li);
    });
  }

  function resetReadout() {
    document.getElementById("prob-value").textContent = "—";
    const verdict = document.getElementById("verdict-value");
    verdict.textContent = "Awaiting input";
    verdict.className = "verdict-value";
    document.getElementById("gauge-fill").setAttribute("stroke-dasharray", "0 100");
    document.getElementById("gauge-needle").style.transform = "rotate(-90deg)";
    document.getElementById("drivers-list").innerHTML = "";
  }

  function handleSubmit(e) {
    e.preventDefault();
    const inputs = document.querySelectorAll("#feature-form input[data-idx]");
    const rawValues = new Array(bundle.feature_names.length).fill(0);
    let valid = true;
    inputs.forEach((inp) => {
      const idx = Number(inp.dataset.idx);
      const v = parseFloat(inp.value);
      if (Number.isNaN(v)) valid = false;
      rawValues[idx] = v;
    });
    if (!valid) {
      alert("Please fill in all 30 fields, or load an example first.");
      return;
    }
    const { probability, contributions } = predict(rawValues);
    updateGauge(probability);
    updateVerdict(probability);
    updateDrivers(contributions);
  }

  async function init() {
    const res = await fetch("model_bundle.json");
    bundle = await res.json();
    buildForm();
    document.getElementById("feature-form").addEventListener("submit", handleSubmit);
    document.querySelectorAll(".chip[data-example]").forEach((btn) => {
      btn.addEventListener("click", () => loadExample(btn.dataset.example));
    });
    resetReadout();
  }

  init();
})();
